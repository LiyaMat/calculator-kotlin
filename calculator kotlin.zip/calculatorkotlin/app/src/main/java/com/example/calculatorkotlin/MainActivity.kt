package com.example.calculatorkotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
    fun buNumberEvent(view: View){

        if(isNewOp){
            etshow.setText("")
        }
        isNewOp=false
        var buttonselect=view as Button
        var buttonclickvalue=etshow.text.toString()
        when(buttonselect.id){
            bu0.id -> buttonclickvalue+="0"
            bu1.id -> buttonclickvalue+="1"
            bu2.id -> buttonclickvalue+="2"
            bu3.id -> buttonclickvalue+="3"
            bu4.id -> buttonclickvalue+="4"
            bu5.id -> buttonclickvalue+="5"
            bu6.id -> buttonclickvalue+="6"
            bu7.id -> buttonclickvalue+="7"
            bu8.id -> buttonclickvalue+="8"
            bu9.id -> buttonclickvalue+="9"
            buttondot.id->buttonclickvalue+="."
            buttonPlusMinus.id->buttonclickvalue+="-$buttonclickvalue"

        }
        etshow.setText(buttonclickvalue)

    }
    var op="*"
    var oldNumber=""
    var isNewOp=true
    fun buOpEevent(view:View){
        val buttonselect = view as Button
        when(buttonselect.id){
            buttonsum.id->op = "+"
            buttonsub.id->op="-"
            buttonmul.id->op="*"
            buttondiv.id->op="/"

        }
        oldNumber=etshow.text.toString()
        isNewOp=true
    }
    fun buEqualEvent(view: View){
        val newNumber=etshow.text.toString()
        var finalNumber:Double?=null
        when(op){
            "+"->finalNumber=oldNumber.toDouble() + newNumber.toDouble()
            "-"->finalNumber=oldNumber.toDouble() - newNumber.toDouble()
            "*"->finalNumber=oldNumber.toDouble() * newNumber.toDouble()
            "/"->finalNumber=oldNumber.toDouble() / newNumber.toDouble()

        }
        etshow.setText(finalNumber.toString())
        isNewOp=true
    }
    fun buPercent(view:View){
        val number:Double=etshow.text.toString().toDouble()/100

        etshow.setText(number.toString())
        isNewOp=true
    }
    fun buClean(view:View){
        etshow.setText("0")
        isNewOp=true
    }

}